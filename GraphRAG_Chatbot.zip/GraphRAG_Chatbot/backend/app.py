import spacy
import re
from fastapi import FastAPI, HTTPException
from neo4j import GraphDatabase

# Load spaCy NLP Model
nlp = spacy.load("en_core_web_sm")

# Neo4j Configuration
NEO4J_URI = "bolt://localhost:7687"
NEO4J_USER = "neo4j"
NEO4J_PASSWORD = "12345678"

driver = GraphDatabase.driver(NEO4J_URI, auth=(NEO4J_USER, NEO4J_PASSWORD))
app = FastAPI()

def get_schema_info():
    """Dynamically get database schema information"""
    with driver.session() as session:
        # Get property keys
        props_query = """
        CALL db.propertyKeys() YIELD propertyKey
        RETURN collect(propertyKey) as properties
        """
        properties = session.run(props_query).single()["properties"]
        
        # Get sample values for each property
        schema = {}
        for prop in properties:
            value_query = f"""
            MATCH (n)
            WHERE n.{prop} IS NOT NULL
            RETURN DISTINCT n.{prop} as value
            LIMIT 5
            """
            values = [record["value"] for record in session.run(value_query)]
            schema[prop] = values
            
        return properties, schema

def extract_query_entities(question, schema):
    """Extract relevant entities based on current schema"""
    doc = nlp(question.lower())
    
    # Get words and their lemmas from the question
    question_words = set([token.text.lower() for token in doc] + 
                        [token.lemma_.lower() for token in doc])
    
    # Match properties and values
    matched_props = []
    matched_values = {}
    
    for prop, values in schema.items():
        # Check if property is mentioned
        if prop.lower() in question_words:
            matched_props.append(prop)
        
        # Check if any values are mentioned
        for value in values:
            str_value = str(value).lower()
            if str_value in question_words:
                matched_values[prop] = value
    
    return matched_props, matched_values

def generate_dynamic_query(props, values):
    """Generate a Cypher query based on extracted entities"""
    conditions = []
    returns = []
    
    # Add value conditions
    for prop, value in values.items():
        if isinstance(value, str):
            conditions.append(f"n.{prop} = '{value}'")
        else:
            conditions.append(f"n.{prop} = {value}")
        if prop not in props:
            props.append(prop)
    
    # Ensure we have properties to return
    if not props:
        props = ['*']  # Return all properties if none specified
    
    # Build return clause
    returns = [f"n.{prop} as {prop}" for prop in props if prop != '*']
    return_clause = ", ".join(returns) if returns else "n"
    
    # Build where clause
    where_clause = " AND ".join(conditions) if conditions else "true"
    
    query = f"""
    MATCH (n)
    WHERE {where_clause}
    RETURN {return_clause}
    """
    
    return query

def clean_response(records):
    """Clean and format the response data"""
    # Remove null values and empty entries
    cleaned = []
    for record in records:
        clean_record = {k: v for k, v in record.items() if v is not None}
        if clean_record:  # Only add if there are non-null values
            cleaned.append(clean_record)
    
    # If all records have the same structure, return just the values
    if cleaned and all(record.keys() == cleaned[0].keys() for record in cleaned):
        # If each record has only one value, return list of values
        if len(cleaned[0].keys()) == 1:
            key = list(cleaned[0].keys())[0]
            return [record[key] for record in cleaned]
    
    return cleaned

@app.get("/query")
async def answer_query(question: str):
    try:
        # Get current schema information
        properties, schema = get_schema_info()
        
        # Extract relevant entities from question
        matched_props, matched_values = extract_query_entities(question, schema)
        
        # Generate and execute query
        query = generate_dynamic_query(matched_props, matched_values)
        
        with driver.session() as session:
            result = session.run(query)
            response = [dict(record) for record in result]
            
            if not response:
                return []
            
            # Clean and format the response
            cleaned_response = clean_response(response)
            return cleaned_response
            
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Query failed: {str(e)}")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)