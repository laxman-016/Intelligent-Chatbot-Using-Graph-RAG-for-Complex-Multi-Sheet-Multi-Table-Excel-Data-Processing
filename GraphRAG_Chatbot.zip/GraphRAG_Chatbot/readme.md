http://localhost:8000/query?question=Account_ID
http://localhost:8000/query?question=Account
http://localhost:8000/query?question=Revenue
http://localhost:8000/query?question=Q1