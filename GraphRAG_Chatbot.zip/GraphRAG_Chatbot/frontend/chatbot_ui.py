import streamlit as st
import requests

st.title("Graph-RAG Chatbot")

question = st.text_input("Ask a financial question:")
if st.button("Ask"):
    response = requests.get(f"http://localhost:8000/query?question={question}").json()
    
    if "error" in response:
        st.error(response["error"])  # ✅ Show error messages
    else:
        st.write(response["response"])
